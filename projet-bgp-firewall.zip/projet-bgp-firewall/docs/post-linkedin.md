🔧 Projet réseau : interconnexion sécurisée de 3 entreprises avec BGP et pare-feu

Dans le cadre d'un labs personnel sous GNS3, j'ai conçu et déployé une architecture réseau
reliant trois entreprises fictives, chacune avec son propre Système Autonome (AS) et son
propre réseau local, en passant obligatoirement par un pare-feu central.

Ce que j'ai mis en œuvre :

📡 Routage BGP — établissement de voisinages eBGP entre 4 routeurs (AS 100, 200, 300 et un
AS de transit), annonce et vérification des préfixes réseau, lecture des tables de routage
et des chemins d'AS.

🔒 Sécurité — définition d'une politique de pare-feu avec ACL étendues nommées : flux
autorisés entre certaines entreprises, blocage strict d'autres, y compris la préservation
du trafic de contrôle BGP (un piège classique : un pare-feu mal placé peut couper le
routage lui-même).

🌐 NAT — configuration de la traduction d'adresses (PAT/overload) pour simuler un accès
Internet partagé depuis chaque réseau local.

🧭 Diagnostic — la partie la plus formatrice : résoudre un problème de câblage physique mal
identifié, un blocage BGP causé par le pare-feu, une pool NAT sous-dimensionnée... Chaque
incident a été isolé méthodiquement (tests couche par couche, tables ARP, compteurs
d'ACL) avant correction.

Ce projet m'a surtout confirmé une chose : en réseau, la configuration n'est que la moitié
du travail — savoir diagnostiquer méthodiquement quand quelque chose ne fonctionne pas
comme prévu est tout aussi essentiel.

#Réseau #BGP #CyberSécurité #GNS3 #Cisco #Firewall #Networking
